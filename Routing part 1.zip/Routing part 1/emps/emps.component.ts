import { Component, OnInit } from '@angular/core';
import { EmpServiceService } from '../emp-service.service';

@Component({
  selector: 'app-emps',
  templateUrl: './emps.component.html',
  styleUrls: ['./emps.component.css']
})
export class EmpsComponent implements OnInit {

  emps: any[] = [];

  constructor(private httpObj: EmpServiceService) { }

  ngOnInit(): void {
    this.httpObj.getData().subscribe((res:any[]) =>
      {
        this.emps = res;
      });
  }

}
