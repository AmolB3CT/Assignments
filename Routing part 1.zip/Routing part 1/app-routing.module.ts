import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { DeptsComponent } from './depts/depts.component';
import { DetailsComponent } from './details/details.component';
import { EmpsComponent } from './emps/emps.component';
import { GalleryComponent } from './gallery/gallery.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {path: "", component: HomeComponent},
  { path :  "Emps", component: EmpsComponent },
      { path :  "Login", component: LoginComponent },
      { path :  "Depts", component: DeptsComponent },
      { path :  "Aboutus", component: AboutComponent },
      { path :  "Details/:id", component: DetailsComponent },
      { path :  "Gallery", component: GalleryComponent },
      { path :  "Contact", component: ContactComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
