import { Directive, ElementRef, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[myShadow]'
})
export class MyShadowDirective implements OnInit {
  @Input() myShadow:string = "";
  constructor(private element: ElementRef) {
    
   }

  ngOnInit(){
    if(this.myShadow==""){
      this.element.nativeElement.style.boxShadow = "10px 20px red";
    }
    else{
      this.element.nativeElement.style.boxShadow = this.myShadow;
    }
  }
}
