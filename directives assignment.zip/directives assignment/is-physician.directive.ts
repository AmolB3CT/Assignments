import { Directive, Input, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[admin]'
})
export class IsPhysicianDirective implements OnInit {
  adminPanel:string[] = ["smith", "john", "mark", "sam", "Mathew"];
  @Input() admin:string ="";
  constructor(private viewContainer: ViewContainerRef, 
    private templateRef: TemplateRef<any> ) { }
  
  ngOnInit(){
    if(this.adminPanel.indexOf(this.admin)>-1){
      this.viewContainer.createEmbeddedView(this.templateRef);
    }
    else{
      this.viewContainer.clear();
    }
  }
}
