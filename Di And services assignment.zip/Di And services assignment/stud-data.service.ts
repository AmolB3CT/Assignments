import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudDataService {
  

  constructor() { }

    dataArray:any[]  =[
    {sid : 101, sname : "Amol", course : "Angular", email: "amol@gmail.com", age: 26},
    {sid : 102, sname : "Ravi", course : "React", email: "ravi@gmail.com", age: 28},
    {sid : 103, sname : "Nikhil", course : "Vue", email: "nikhil@gmail.com", age: 25},
    {sid : 104, sname : "Suraj", course : "Java", email: "suraj@gmail.com", age: 29},
  ];

  getStudData():any[]
  {
    return this.dataArray;
  }

  removeStudData(sid:number)
  {
    let index  =  this.dataArray.findIndex(   item =>  item.sid == sid    );
    this.dataArray.splice(index,  1);
  }


  addStud(studObj:any): void
  {
    this.dataArray.push(studObj);
  }
}
