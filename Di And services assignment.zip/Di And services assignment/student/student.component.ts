import { Component, OnInit } from '@angular/core';
import { StudDataService } from '../stud-data.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  sid:number = 0;
  sname:string = "";
  course:string = "";
  age:number = 0;
  email:string = "";
  isDisabled :boolean = false;

  public studArray:Stud[] = [];

  constructor(public dataService: StudDataService) {
  
   }

  ngOnInit(): void {
  }

  getStudData_click(){
    this.studArray = this.dataService.getStudData()
  }

  addStud_click()
  {
    let studObj:Stud = new Stud();
    studObj.sid = this.sid;
    studObj.sname = this.sname;
    studObj.course = this.course;
    studObj.email = this.email;
    studObj.age = this.age;

    this.dataService.addStud(studObj);;
    this.clearFields();
  }

  removeStudData_click(sid:number)
  {
    this.dataService.removeStudData(sid);
        this.studArray= this.dataService.getStudData();
  }

  // public studArray:Stud[] = [];  

  // getStudData()
  // {
  //   this.studArray  =[
  //     {sid : 101, sname : "Amol", course : "Angular", email: "amol@gmail.com", age: 26},
  //     {sid : 102, sname : "Ravi", course : "React", email: "ravi@gmail.com", age: 28},
  //     {sid : 103, sname : "Nikhil", course : "Vue", email: "nikhil@gmail.com", age: 25},
  //     {sid : 104, sname : "Suraj", course : "Java", email: "suraj@gmail.com", age: 29},
  //   ];
  // }

  // removeStudData(sid:number)
  // {
  //   let index  =  this.studArray.findIndex(   item =>  item.sid == sid    );
  //   this.studArray.splice(index,  1);
  // }


  // selectStudData(sid:number)
  // {
	// 	let studObj:any =  this.studArray.find(   item =>  item.sid == sid    );
	// 	this.sid =   studObj.sid;
	// 	this.sname =   studObj.sname;
	// 	this.course 		=  studObj.course;
  //   this.email = studObj.email;
  //   this.age = studObj.age;
  //   this.isDisabled = true;
  // }

  // updateStudData()
  // {
  //   let index  =  this.studArray.findIndex(   item =>  item.sid == this.sid    );
  //   this.studArray[index].sname = this.sname;
  //   this.studArray[index].course = this.course;
  //   this.studArray[index].email = this.email;
  //   this.studArray[index].age = this.age;
  //   this.clearFields();

  // }

  clearFields()
  {
      this.isDisabled = false;
      this.sid = 0;
      this.sname  = "";
      this.course  = "";
      this.email = "";
      this.age = 0;
  }


  // addStud()
  // {
  //   let studObj:Stud = new Stud();
  //   studObj.sid = this.sid;
  //   studObj.sname = this.sname;
  //   studObj.course = this.course;
  //   studObj.email = this.email;
  //   studObj.age = this.age;

  //   this.studArray.push(studObj);
  //   this.clearFields();
  // }
}

class Stud
{
  sid  : number = 0;
  sname  : string  = "";
  course  : string  = "";
  age  : number = 0;
  email  : string  = "";
}