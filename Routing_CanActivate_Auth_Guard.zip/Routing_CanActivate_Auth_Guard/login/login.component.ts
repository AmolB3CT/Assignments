import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersServiceService } from '../users-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  public email: string = "";
    public password: string = "";
    public result: string = "";
    userObj: any = {}
    constructor(private router: Router, private activatedRoute: ActivatedRoute, private httpObj: HttpClient) { }


    login_click()
    {

       let requestedUrl = this.activatedRoute.snapshot.queryParams["returnUrl"];

       if(requestedUrl == "" || requestedUrl == null)
       {
         requestedUrl = "/";
       }
        
        this.userObj = {email:this.email, password:this.password };
        this.httpObj.post<any>("http://localhost:3200/login",this.userObj).subscribe((res:any) =>
          {
            sessionStorage.setItem("AUTH_TOKEN",  res.accessToken);
            this.router.navigate([requestedUrl]);          },

            (error)=> {
              this.result  ="Invalid user id or password";

            })
          
      
    }

}
