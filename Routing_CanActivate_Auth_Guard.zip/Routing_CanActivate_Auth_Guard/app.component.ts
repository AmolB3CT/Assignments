import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(router: Router){}

  logout_click(){
    sessionStorage.removeItem("AUTH_TOKEN");
    // this.router.navigate([/]);

  }


  // selectedJob:string  = "All Employees";

  // change_job_parent(str:string)
  // {
  //   this.selectedJob = str;
  // }
    
  // selectedSort:string  = "";

  // change_sort_parent(str:string)
  // {
  //   this.selectedSort = str;
  // }
    
}

