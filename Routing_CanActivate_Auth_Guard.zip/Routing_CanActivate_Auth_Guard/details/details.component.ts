import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmpServiceService } from '../emp-service.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  empObj:any = {};

  emps:any[] = [];
  tempArray: any[] = [];

  constructor(private activatedRoute: ActivatedRoute, private httpObj: EmpServiceService) {  }


  ngOnInit(): void {
    let eno = this.activatedRoute.snapshot.params["id"];

     this.httpObj.getDataById(eno).subscribe((res:any) =>
      {

        this.empObj = res;

      });

    // alert("Selected Empno  : " + eno);

  }
  

}
