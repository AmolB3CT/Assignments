import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { StudentComponent } from './student/student.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ProdComponent } from './prod/prod.component';
import { ProdFilterComponent } from './prod-filter/prod-filter.component';
import { PipeExampleComponent } from './pipe-example/pipe-example.component';
import { GradePipe } from './grade.pipe';
import { RatingPipe } from './rating.pipe';
import { RangePipe } from './range.pipe';
import { DemoComponent } from './demo/demo.component';
import { MyShadowDirective } from './my-shadow.directive';
import { IsPhysicianDirective } from './is-physician.directive';
import { CrudopsComponent } from './crudops/crudops.component';
import { Crupdops1Component } from './crupdops1/crupdops1.component';
// import { CustomHttpInterceptorService } from './custom-http-interceptor.service';
import { TemplateformComponent } from './templateform/templateform.component';
import { ReactiveformComponent } from './reactiveform/reactiveform.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { EmpsComponent } from './emps/emps.component';
import { DeptsComponent } from './depts/depts.component';
import { LoginComponent } from './login/login.component';
import { ContactComponent } from './contact/contact.component';
import { GalleryComponent } from './gallery/gallery.component';
import { DetailsComponent } from './details/details.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    StudentComponent,
    EmployeeComponent,
    EmployeeDetailsComponent,
    ProdComponent,
    ProdFilterComponent,
    PipeExampleComponent,
    GradePipe,
    RatingPipe,
    RangePipe,
    DemoComponent,
    MyShadowDirective,
    IsPhysicianDirective,
    CrudopsComponent,
    Crupdops1Component,
    TemplateformComponent,
    ReactiveformComponent,
    HomeComponent,
    AboutComponent,
    EmpsComponent,
    DeptsComponent,
    LoginComponent,
    ContactComponent,
    GalleryComponent,
    DetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  // providers: [{provide : HTTP_INTERCEPTORS, useClass: CustomHttpInterceptorService, multi:true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
