import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe-example',
  templateUrl: './pipe-example.component.html',
  styleUrls: ['./pipe-example.component.css']
})
export class PipeExampleComponent implements OnInit {

//   start:number = 0;
//   end: number = 4;
//   isDisabled:boolean = false;

//   usersArray:any[] =
// [           
//   {"id":1,"email":"george.bluth@reqres.in","first_name":"George","last_name":"Bluth","avatar":"https://reqres.in/img/faces/1-image.jpg"},
//     {"id":2,"email":"janet.weaver@reqres.in","first_name":"Janet","last_name":"Weaver","avatar":"https://reqres.in/img/faces/2-image.jpg"},
//     {"id":3,"email":"emma.wong@reqres.in","first_name":"Emma","last_name":"Wong","avatar":"https://reqres.in/img/faces/3-image.jpg"},
//     {"id":4,"email":"eve.holt@reqres.in","first_name":"Eve","last_name":"Holt","avatar":"https://reqres.in/img/faces/4-image.jpg"},
//     {"id":5,"email":"charles.morris@reqres.in","first_name":"Charles","last_name":"Morris","avatar":"https://reqres.in/img/faces/5-image.jpg"},
//     {"id":6,"email":"tracey.ramos@reqres.in","first_name":"Tracey","last_name":"Ramos","avatar":"https://reqres.in/img/faces/6-image.jpg"},

//     {"id":7,"email":"george.bluth@reqres.in","first_name":"George","last_name":"Bluth","avatar":"https://reqres.in/img/faces/1-image.jpg"},
//     {"id":8,"email":"janet.weaver@reqres.in","first_name":"Janet","last_name":"Weaver","avatar":"https://reqres.in/img/faces/2-image.jpg"},
//     {"id":9,"email":"emma.wong@reqres.in","first_name":"Emma","last_name":"Wong","avatar":"https://reqres.in/img/faces/3-image.jpg"},
//     {"id":10,"email":"eve.holt@reqres.in","first_name":"Eve","last_name":"Holt","avatar":"https://reqres.in/img/faces/4-image.jpg"},
//     {"id":11,"email":"charles.morris@reqres.in","first_name":"Charles","last_name":"Morris","avatar":"https://reqres.in/img/faces/5-image.jpg"},
//     {"id":12,"email":"tracey.ramos@reqres.in","first_name":"Tracey","last_name":"Ramos","avatar":"https://reqres.in/img/faces/6-image.jpg"},

//     {"id":13,"email":"charles.morris@reqres.in","first_name":"Charles","last_name":"Morris","avatar":"https://reqres.in/img/faces/5-image.jpg"},
//     {"id":14,"email":"tracey.ramos@reqres.in","first_name":"Tracey","last_name":"Ramos","avatar":"https://reqres.in/img/faces/6-image.jpg"}
// ];

//   load_more_click(){
//     this.start = this.start;
//     this.end = this.end + 4;

//     if(this.start >=  this.usersArray.length)
//         {
//           this.isDisabled = true;
//         }
//   }


  // employeeArray:any[]= [
  //   {srno: 1, name: "John Doe", grade:4, rating: 2 },
  //   {srno: 2, name: "Shaun Marsh", grade:1, rating: 5 },
  //   {srno: 3, name: "Brett Lee", grade:4, rating: 2  },
  //   {srno: 4, name: "Shyam patil", grade:2, rating: 4  },
  //   {srno: 5, name: "Smith shaw", grade:1, rating: 5 },
  //   {srno: 6, name: "mark Doe", grade:2, rating: 4 },
  //   {srno: 7, name: "Ricky Marsh", grade:4, rating: 2 },
  //   {srno: 8, name: "Steyn Joshua", grade:3, rating: 3 },
  //   {srno: 9, name: "Smith Doe", grade:2, rating: 4 },
  //   {srno: 10, name: "John Turner", grade:1, rating: 5 }

  // ]

  selectedMinVal:number = 0;
  selectedMaxVal:number = 0;

  employeeArray:any[]= [
    {srno: 1, name: "John Doe", desigantion: "Manager", salary: 70000 },
    {srno: 2, name: "Shaun Marsh", desigantion: "Clerk", salary: 40000 },
    {srno: 3, name: "Brett Lee", desigantion: "Analyst", salary: 30000  },
    {srno: 4, name: "Shyam patil", desigantion: "Salesman", salary: 20000  },
    {srno: 5, name: "Smith shaw", desigantion: "Clerk", salary: 50000 },
    {srno: 6, name: "mark Doe", desigantion: "Analyst", salary: 40000 },
    {srno: 7, name: "Ricky Marsh", desigantion: "Salesman", salary: 25000 },
    {srno: 8, name: "Steyn Joshua", desigantion: "Manager", salary: 65000 },
    {srno: 9, name: "Smith Doe", desigantion: "Clerk", salary: 35000 },
    {srno: 10, name: "John Turner", desigantion: "Analyst", salary: 38000 }

  ]

  constructor() { }

  ngOnInit(): void {
  }

}
