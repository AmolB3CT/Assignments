import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'rating'
})
export class RatingPipe implements PipeTransform {

  transform() 
  {
    // let output:string[]  = [];

    // let i = 0;
    // for(i=1; i<=5; i++){
    //   if(i<=input){
    //     output.push();
    //   }
    //     else{
    //       output.push()
    //     }
      
    // }

    // return output;
  }

}
