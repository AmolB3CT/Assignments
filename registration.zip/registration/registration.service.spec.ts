import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { RegistrationService } from './registration.service';import { UserDetails } from '../login/login.component';



const sampleData:any[] = [
  {
    "id": 1,
    "userpass": "login123",
    "firstname": "vishwanth",
    "lastname": "kota",
    "email": "kota.vishwanth@example.com",
    "role": "Patient",
    "dob": "12/08/1947",
    "username": "vishwanthk",
    "phone": "206-555-1212"
  },
  {
    "id": 2,
    "userpass": "login123",
    "firstname": "varsha",
    "lastname": "balapuram",
    "email": "balapuram.varsha@example.com",
    "role": "Patient",
    "dob": "12/08/1927",
    "username": "varshab",
    "phone": "206-555-1212"
  },
  {
    "id": 3,
    "userpass": "login123",
    "firstname": "Amol",
    "lastname": "Bundelkhandi",
    "email": "Bundelkhandi.Amol@example.com",
    "role": "Patient",
    "dob": "12/08/1947",
    "username": "amolb",
    "phone": "206-555-1212"
  }
  
];

describe('RegistrationService', () => {
  let service: RegistrationService;
  let httpClientSpy: { get: jasmine.Spy, post: jasmine.Spy };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers:  [RegistrationService]
    });

    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post']);
    service = new RegistrationService(httpClientSpy as any);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get data from the server as an Observable<any[]>',   ( done:DoneFn ) => {

    httpClientSpy.get.and.returnValue(of(sampleData));

    service.getData().subscribe(
      (resData) => {
        expect(resData).toEqual(sampleData);
        done();
      },
      done.fail
    );

    expect(httpClientSpy.get.calls.count()).toBe(1);

  });

  it('should perform post operation to add new person in registration details',   ( done ) => {

    let obj:any = { "id": 8, "firstname": "Shyam",  "lastname": "Rao", "email": "shyam@gmail.com", "role": "patient",  "dob": "13/12/1980", "username": "shyam123", "phone": "8788766543" };
    httpClientSpy.post.and.returnValue(of(obj));

    service.addPerson(obj).subscribe(
      (resData:any) => {
        expect(resData).toEqual(obj);
        done();
      },
      done.fail
    );

    expect(httpClientSpy.post.calls.count()).toBe(1);

  });

  it('should get data from the server for the specific "username" ',   ( done:DoneFn ) => {

    httpClientSpy.get.and.returnValue(of(sampleData[2]));

    let uname:string = "amolb";
    service.getLoginData(uname).subscribe(
      (resData) => {
        expect(resData).toEqual(sampleData[2]);
        done();
      },
      done.fail
    );

    expect(httpClientSpy.get.calls.count()).toBe(1);

  });
  
  it('should perform post operation to add new users to loginData',   ( done ) => {

    let obj:any = { "id": 8, "firstname": "Shyam",  "lastname": "Rao", "email": "shyam@gmail.com", "role": "patient",  "dob": "13/12/1980", "username": "shyam123", "phone": "8788766543" };
    httpClientSpy.post.and.returnValue(of(obj));

    service.addLoginData(obj).subscribe(
      (resData:any) => {
        expect(resData).toEqual(obj);
        done();
      },
      done.fail
    );

    expect(httpClientSpy.post.calls.count()).toBe(1);

  });
});
