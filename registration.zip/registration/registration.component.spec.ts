import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { RegistrationComponent } from './registration.component';
import { RegistrationService } from './registration.service';

describe('RegistrationComponent', () => {
  let component: RegistrationComponent;
  let fixture: ComponentFixture<RegistrationComponent>;
  let registrationServiceSpy: { getData: jasmine.Spy};

  beforeEach(async () => {

    registrationServiceSpy = jasmine.createSpyObj('RegistrationService', ['getData']);

    await TestBed.configureTestingModule({
      declarations: [ RegistrationComponent ],
      providers: [{ provide : RegistrationService, useValue : registrationServiceSpy},
    
      ],
      imports: [HttpTestingController, HttpClientTestingModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should showError property contains false value as defualt value', () => {

    const strOutput:boolean  = component.showError;
    expect(strOutput).toBe(false);
    // expect(registrationServiceSpy.getData).toHaveBeenCalled()
  });
});
